import { View, Text } from 'react-native';

export default function ChartsScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Gráficos</Text>
    </View>
  );
}
