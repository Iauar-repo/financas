const LOCAL_IP = '192.168.0.20';
const API_PORT = 5000;

export const API_URL = `http://${LOCAL_IP}:${API_PORT}`;