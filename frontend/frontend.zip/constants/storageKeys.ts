export const STORAGE_KEYS = {
  authToken: 'authToken',
  refreshToken: 'refreshToken',
  rememberedUsername: 'rememberedUsername',
};
